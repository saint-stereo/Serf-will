# Security Policy

If you discover a vulnerability or misuse path, please open a private security
advisory on GitHub or contact the maintainers listed in `CITATION.cff`.