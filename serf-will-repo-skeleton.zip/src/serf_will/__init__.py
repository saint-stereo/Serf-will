"""
SERF reference implementations (proto‑will demos).
"""