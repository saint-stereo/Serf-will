import numpy as np

def schmitt_flip_rate(sigma: float, A: float = 100.0, beta: float = 0.1,
                      V_hyst: float = 0.5, N: int = 50_000, seed: int | None = None) -> float:
    """
    Monte-Carlo estimate of spontaneous flip frequency in a Schmitt trigger.
    Returns flips/N (dimensionless rate per sample).
    """
    rng = np.random.default_rng(seed)
    V_in = np.linspace(-1, 1, N) + rng.normal(0.0, sigma, N)
    V_out = 0.0
    flips = 0
    for i in range(N-1):
        V_th = beta * V_out
        near = abs(V_in[i] - V_th) < V_hyst / 2
        if near:
            if V_in[i] > V_th and V_out <= 0.0:
                V_out = 5.0
                flips += 1
            elif V_in[i] < V_th and V_out >= 5.0:
                V_out = 0.0
                flips += 1
    return flips / N

def kramers_rate(sigmas, A: float = 100.0, beta: float = 0.1):
    """
    Analytic Kramers prediction for escape over a barrier.
    """
    sigmas = np.asarray(sigmas)
    dV = 0.5 * (beta**2) * A
    w_p = np.sqrt(1 + beta*A)
    w_s = np.sqrt(abs(1 - beta*A))
    pref = (w_p * w_s) / (2*np.pi)
    return pref * np.exp(-dV / (sigmas**2))
