import numpy as np

def entropy(pi):
    pi = np.clip(pi, 1e-12, 1.0)
    return -(pi * np.log(pi)).sum()

def proto_will_signal(delta: float, C: float, eta: float = 1.0) -> float:
    """
    R_int = eta * |delta| * C
    """
    return eta * abs(delta) * C
