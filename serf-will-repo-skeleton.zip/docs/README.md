# Docs

Place the SERF paper (Markdown or PDF) here. Suggested filename:
`serf_formalizing_emergent_will.md`.

Link the DOI here after Zenodo is minted.