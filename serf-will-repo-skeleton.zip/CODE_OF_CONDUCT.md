# Code of Conduct

We are committed to a welcoming, harassment‑free collaboration space. We follow
the Contributor Covenant 2.1 in spirit. Report issues via GitHub Issues or email
listed in `CITATION.cff`. Violations may result in moderation actions.