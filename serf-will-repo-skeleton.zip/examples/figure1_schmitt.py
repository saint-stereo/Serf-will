#!/usr/bin/env python3
"""
Figure 1 reproduction: flip rate vs noise for a Schmitt trigger.
"""
import numpy as np
import matplotlib.pyplot as plt
from serf_will.schmitt import schmitt_flip_rate, kramers_rate

sigmas = np.logspace(-2, 0, 12)
sim = np.array([schmitt_flip_rate(s) for s in sigmas])
kram = kramers_rate(sigmas)

plt.figure()
plt.loglog(sigmas, sim, 'o', label='Simulation')
plt.loglog(sigmas, kram, '-', label='Kramers')
plt.xlabel('Thermal noise σ')
plt.ylabel('Flip rate f_will')
plt.title('Flip Rate vs Noise (Schmitt trigger)')
plt.legend()
plt.grid(True, which='both')
plt.tight_layout()
plt.savefig('figure1_flip_rate_vs_noise.png', dpi=160)
print("Saved figure1_flip_rate_vs_noise.png")
